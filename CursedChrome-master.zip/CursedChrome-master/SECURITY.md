# Security Policy

## Reporting a Vulnerability

For security vulnerabilities please report them to mandatory (at) gmail (.) com. I'll try to fix issues as soon as possible (although keep in mind, this is a side-project and there are only so many hours in a day so bare with me).
